# from django import views
# from django.urls import url
# from django.conf.urls import include,re_path

from django.urls import include, re_path
from. views import HomePageView,county_datasets

urlpatterns = [
    re_path(r'^$', HomePageView.as_view(),name='home'),
    re_path(r'^Trial_class/$', HomePageView.as_view(),name='home'),
    re_path(r'^Counties/$', county_datasets ,name='county'),
]
