from django.contrib import admin
from. models import  Trial_class,Counties

from leaflet.admin import LeafletGeoAdmin
# Register your models here.
# admin.site.register(Trial_class)
class Trial_classADMIN(LeafletGeoAdmin):
    list_display =('Name','location')
    pass
admin.site.register(Trial_class,Trial_classADMIN)

class countiesAdmin(LeafletGeoAdmin):
    list_display=('county_nam','count')
    pass
admin.site.register(Counties,countiesAdmin)