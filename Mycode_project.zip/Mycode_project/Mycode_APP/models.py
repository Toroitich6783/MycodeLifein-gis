from django.db import models
from django.contrib.gis.db import models
from django.db.models import Manager as Geomanager

# Create your models here.
class Trial_class(models.Model):
    Name=models.CharField(max_length=254)
    location=models.PointField(srid=4326)
    
class Counties(models.Model):
    objectid = models.IntegerField()
    county_nam = models.CharField(max_length=50)
    count = models.FloatField()
    shape_leng = models.FloatField()
    shape_area = models.FloatField()
    geom = models.MultiPolygonField(srid=4326)
    
    def _unicode_(self):
        return self.Counties