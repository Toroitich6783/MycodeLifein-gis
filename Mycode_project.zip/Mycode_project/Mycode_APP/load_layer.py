# from base64 import encode
# from email.policy import strict
# import encodings
from django.db import models
from models import Counties
import os
from django.contrib.gis.utils import LayerMapping
# from matplotlib import transforms 

 
counties_mapping = {
    'objectid': 'OBJECTID',
    'county_nam': 'COUNTY_NAM',
    'count': 'COUNT',
    'shape_leng': 'Shape_Leng',
    'shape_area': 'Shape_Area',
    'geom': 'MULTIPOLYGON',
}
county_shp = os.path.abspath(os.path.join(os.path.dirname(__file__),'data/Counties.shp'))
def run(verbose=True):
    lm=LayerMapping(Counties,counties_mapping, transforms=False,encoding='iso-8859-1')
    lm.save(strict= True,verbose=verbose)